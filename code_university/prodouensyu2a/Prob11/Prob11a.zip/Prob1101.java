public class Prob1101 extends Super1101{
    public static void main(String[] args) {
        Prob1101 a = new Prob1101();
        a.testMethod();
    }
        @Override
        public void testMethod(){
            System.out.println("This is an anotation example");
        }
}
