public class Prob1103 implements Runnable{
	public static void main(String[] args) {
		Prob1103 a = new Prob1103();
		a.run();
	}

	@Override
	public void run() {
		System.out.println("Hello World!");
	}
	
}
