public class SimplePrinter implements Printer{
	public void print(int i) {
		System.out.println(i);
	}
}

