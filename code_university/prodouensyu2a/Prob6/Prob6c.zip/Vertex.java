public abstract class Vertex extends Turtle{
    abstract void draw(Turtle t);    
}
