public class Prob13{
    public static void main(String[] args){
        System.out.println("My name is NishimuraTakayuki ID number is  62015188");
        for(int i=1;i<4;i++){
            System.out.println(i + " : Hello World!");
        }
        System.out.println("Goodbye World!");
    }
}