public class Prob15 {
    public static void main(String[] args){
        int i = 4;
        int j = 8;
        boolean x=j==4||i>0&&j>0;
        System.out.println(x);
    }
}
