public class Prob14 {
    public static void main(String[] args){
        int i=3,j=2;
        int k = i++ - ++j;
        System.out.println(i+""+j+""+k);
    }
}
