public class Senior extends Person{
    public Senior(String name,int possesion){
        super(name,possesion);
    }
    @Override
    int getFee() {
        // TODO Auto-generated method stub
        return 60;
    }
}
