public class Child extends Person{
    public Child(String name,int possesion){
        super(name,possesion);
    }
    @Override
    int getFee() {
        // TODO Auto-generated method stub
        return 100;
    }
}
