public class Prob27 {
    public static void main(String[] args){
        ComplexNumber p = new ComplexNumber();
        ComplexNumber q = new ComplexNumber();
        p.x = 20;
        p.y = 22;

        q.x = 4;
        q.y = 15;

        p.print();
        p.abs();
        
        q.print();
        q.abs();
    }
}
