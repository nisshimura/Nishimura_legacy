public class Prob26 {
    public static void main(String[] args){
        MyPointNew p = new MyPointNew();
        MyPointNew q = new MyPointNew();

        p.setPoint(20, 22);
        q.setPoint(4, 15);

        p.printCoord();
        q.printCoord();
    }
}
