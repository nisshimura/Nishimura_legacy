public class Prob23 { public static void main(String[] args) {
    Turtle t,t_six;
    t = new Turtle();
    t_six = new Turtle();
    t.move(10, 200);
    t.penDown();
    t.go(60);
    t.rotate(90);
    t.go(60);
    t.rotate(90);
    t.go(60);
    t.rotate(90);
    t.go(60);

    t_six.move(120, 200);
    t_six.penDown();
    t_six.go(60);
    t_six.rotate(60);
    t_six.go(60);
    t_six.rotate(60);
    t_six.go(60);
    t_six.rotate(60);
    t_six.go(60);
    t_six.rotate(60);
    t_six.go(60);
    t_six.rotate(60);
    t_six.go(60);
    }
    }
