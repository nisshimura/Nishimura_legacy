public class Prob24 { public static void main(String[] args) {
    Turtle t;
    t = new Turtle();
    t.move(200, 200);
    t.penDown();
    t.setColor(java.awt.Color.blue);
    t.go(60);
    t.rotate(45);
    t.setColor(java.awt.Color.red);
    t.go(60);
    t.rotate(45);
    t.setColor(java.awt.Color.yellow);
    t.go(60);
    t.rotate(45);
    t.setColor(java.awt.Color.blue);
    t.go(60);
    t.rotate(45);
    t.setColor(java.awt.Color.red);
    t.go(60);
    t.rotate(45);
    t.setColor(java.awt.Color.yellow);
    t.go(60);
    t.rotate(45);
    t.setColor(java.awt.Color.blue);
    t.go(60);
    t.rotate(45);
    t.setColor(java.awt.Color.red);
    t.go(60);
    t.rotate(45);
    }
    }