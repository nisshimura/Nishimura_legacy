#include <stdio.h>
int main()
{
    printf("My First Program!\nDeveloped by NishimuraTakayuki");
    return 0;
}