#include <stdio.h>
int main()
{
    printf("\"Hello! How are you?\"");
    return 0;
}