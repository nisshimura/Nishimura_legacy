#include <stdio.h>
int main()
{
    printf("quotient is %d and remainderis %d",1234/7,1234%7);
    return 0;
}