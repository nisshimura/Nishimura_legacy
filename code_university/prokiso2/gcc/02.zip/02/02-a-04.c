#include <stdio.h>
int main()
{
    printf("1.234 + 5.678 = %f", 1.234 + 5.678);
    return 0;
}