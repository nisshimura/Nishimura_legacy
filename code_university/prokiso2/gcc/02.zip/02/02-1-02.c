#include <stdio.h>
int main()
{
    printf("1234 - 5678 = %d\n", 1234 + 5678);
    printf("1234 - 5678 = %d", 1234 - 5678);
    return 0;
}